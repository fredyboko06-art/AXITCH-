"use client"

import { useState, useRef, useEffect } from "react"
import { QRCodeSVG } from "qrcode.react"
import {
  Share2,
  Download,
  Copy,
  CheckCircle,
  Link2,
  MapPin,
  Star,
  Send,
  Camera,
  X,
  MessageCircle,
  Home,
  User,
  Navigation,
  Phone,
  ShoppingBag,
  Settings,
  Bell,
  Edit3,
  Grid3X3,
  Heart,
  Clock,
  LogOut,
  ChevronRight,
  Search,
  Filter,
  Apple,
  Shirt,
  Briefcase,
  Gem,
  Smartphone,
  Sofa,
  Car,
  Wrench,
  Palette,
  Leaf,
  UtensilsCrossed,
  Baby,
  Dumbbell,
  BookOpen,
  Music,
  PawPrint,
  Hammer,
  Store,
  UserPlus,
  Lock,
  Mail,
  Calendar,
  ChevronLeft,
  Check,
  Eye,
  EyeOff,
  ShieldCheck,
  Package,
  Users,
  HelpCircle,
  Moon,
  Globe,
  Trash2,
  Image,
  Plus,
} from "lucide-react"

// Catégories du marché
const CATEGORIES = [
  { id: "tous", nom: "Tous", icon: Grid3X3, couleur: "#00FF88" },
  { id: "alimentation", nom: "Alimentation", icon: Apple, couleur: "#FF6B6B" },
  { id: "vetements", nom: "Vêtements", icon: Shirt, couleur: "#4ECDC4" },
  { id: "sacs", nom: "Sacs & Accessoires", icon: Briefcase, couleur: "#FFE66D" },
  { id: "bijoux", nom: "Bijoux", icon: Gem, couleur: "#FF69B4" },
  { id: "electronique", nom: "Électronique", icon: Smartphone, couleur: "#45B7D1" },
  { id: "maison", nom: "Maison & Déco", icon: Sofa, couleur: "#96CEB4" },
  { id: "vehicules", nom: "Véhicules", icon: Car, couleur: "#A8E6CF" },
  { id: "services", nom: "Services", icon: Wrench, couleur: "#DDA0DD" },
  { id: "artisanat", nom: "Artisanat", icon: Palette, couleur: "#F7DC6F" },
  { id: "agriculture", nom: "Agriculture", icon: Leaf, couleur: "#82E0AA" },
  { id: "restaurant", nom: "Restaurants", icon: UtensilsCrossed, couleur: "#F5B041" },
  { id: "bebe", nom: "Bébé & Enfant", icon: Baby, couleur: "#BB8FCE" },
  { id: "sport", nom: "Sport & Loisirs", icon: Dumbbell, couleur: "#5DADE2" },
  { id: "livres", nom: "Livres & Médias", icon: BookOpen, couleur: "#DC7633" },
  { id: "musique", nom: "Musique", icon: Music, couleur: "#E74C3C" },
  { id: "animaux", nom: "Animaux", icon: PawPrint, couleur: "#A569BD" },
  { id: "construction", nom: "Construction", icon: Hammer, couleur: "#7F8C8D" },
]

// Mots interdits pour le chat - Arnaque, drague, seduction, immoralite
const MOTS_INTERDITS = [
  // Drague et seduction
  "bb", "bébé", "bebe", "amour", "chéri", "cheri", "chérie", "cherie", "mon coeur", "ma belle", 
  "ma cherie", "mon amour", "je t'aime", "bisou", "bisous", "calin", "câlin", "doudou",
  "ma puce", "mon ange", "beauté", "belle", "beau gosse", "bg", "crush", "date", "rdv",
  "rencontre", "rendez-vous", "on se voit", "tu me plais", "je te kiffe", "kiffe",
  
  // Sexe et nudite
  "sexe", "sexy", "sexuel", "nue", "nu", "nude", "nudes", "xxx", "porn", "porno",
  "coucher", "lit", "baiser", "faire l'amour", "intime", "intimité", "corps", "poitrine",
  "fesse", "fesses", "seins", "penis", "vagin", "orgasme", "excité", "excitée",
  "coquin", "coquine", "hot", "chaud", "chaude", "désir", "désirer",
  
  // Arnaque et fraude
  "arnaque", "arnaquer", "gratuit", "argent facile", "gagner argent", "bitcoin", "crypto",
  "investissement", "investir", "bénéfice garanti", "million", "millionnaire", "riche rapidement",
  "carte bancaire", "numéro carte", "code secret", "mot de passe", "password", "pin",
  "virement", "transfert argent", "western union", "moneygram", "mobile money", "envoie argent",
  "prêt", "crédit facile", "sans intérêt", "héritage", "loterie", "gagné", "félicitations",
  "urgent", "aide financière", "bloqué", "coincé", "sos", "secours argent",
  
  // Manipulation et chantage
  "menace", "menacer", "chantage", "photo compromettante", "vidéo privée", "pirater",
  "hacker", "compte piraté", "mot de passe", "identifiant",
  
  // Rencontres inappropriees
  "plan cul", "plan q", "one night", "aventure", "relation", "célibataire", "cherche femme",
  "cherche homme", "âge", "quel age", "tu as quel", "photo de toi", "ta photo", "ton numero",
  "whatsapp perso", "appelle moi", "mp", "dm", "message privé", "en privé", "discretement"
]

// Patterns suspects (expressions regulieres)
const PATTERNS_SUSPECTS = [
  /\b\d{10,}\b/, // Numeros de telephone dans les messages
  /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/, // Emails
  /https?:\/\/[^\s]+/, // Liens
  /\b\d+\s*(fcfa|cfa|euros?|dollars?|\$|€)\s*(gratuit|cadeau|offert)/i, // Offres suspectes
]

// Alerte pour les images
const ALERTE_IMAGE = `ATTENTION: L'envoi de photos inappropriees (nudite, contenu explicite) est strictement interdit et entrainera la suspension immediate de votre compte.`

// Données fake pour test - Produits du Bénin
const PRODUITS_INITIAUX = [
  {
    id: 1,
    titre: "Tissus Kente authentique",
    prix: 25000,
    ville: "Cotonou",
    categorie: "vetements",
    image: "/placeholder.svg?height=300&width=300",
    vendeur: {
      id: 1,
      nom: "Mama Adjovi",
      photo: "/placeholder.svg?height=100&width=100",
      note: 4.8,
      avis: 127,
      whatsapp: "+22997000001",
      lat: 6.3654,
      lng: 2.4183,
      produits: 24,
      membres_depuis: "2023",
    },
  },
  {
    id: 2,
    titre: "Tomates fraîches du jardin",
    prix: 1500,
    ville: "Porto-Novo",
    categorie: "alimentation",
    image: "/placeholder.svg?height=300&width=300",
    vendeur: {
      id: 2,
      nom: "Codjo Atchadé",
      photo: "/placeholder.svg?height=100&width=100",
      note: 4.5,
      avis: 89,
      whatsapp: "+22996000002",
      lat: 6.4969,
      lng: 2.6283,
      produits: 15,
      membres_depuis: "2022",
    },
  },
  {
    id: 3,
    titre: "Sac en cuir artisanal",
    prix: 18000,
    ville: "Cotonou",
    categorie: "sacs",
    image: "/placeholder.svg?height=300&width=300",
    vendeur: {
      id: 3,
      nom: "Sèna Kpossou",
      photo: "/placeholder.svg?height=100&width=100",
      note: 4.9,
      avis: 256,
      whatsapp: "+22995000003",
      lat: 6.3628,
      lng: 2.4264,
      produits: 42,
      membres_depuis: "2021",
    },
  },
  {
    id: 4,
    titre: "Collier en perles traditionnelles",
    prix: 5500,
    ville: "Abomey",
    categorie: "bijoux",
    image: "/placeholder.svg?height=300&width=300",
    vendeur: {
      id: 1,
      nom: "Mama Adjovi",
      photo: "/placeholder.svg?height=100&width=100",
      note: 4.8,
      avis: 127,
      whatsapp: "+22997000001",
      lat: 6.3654,
      lng: 2.4183,
      produits: 24,
      membres_depuis: "2023",
    },
  },
  {
    id: 5,
    titre: "Poterie artisanale Sèmè",
    prix: 8500,
    ville: "Porto-Novo",
    categorie: "artisanat",
    image: "/placeholder.svg?height=300&width=300",
    vendeur: {
      id: 2,
      nom: "Codjo Atchadé",
      photo: "/placeholder.svg?height=100&width=100",
      note: 4.5,
      avis: 89,
      whatsapp: "+22996000002",
      lat: 6.4969,
      lng: 2.6283,
      produits: 15,
      membres_depuis: "2022",
    },
  },
  {
    id: 6,
    titre: "Panier tressé Dantokpa",
    prix: 3500,
    ville: "Cotonou",
    categorie: "maison",
    image: "/placeholder.svg?height=300&width=300",
    vendeur: {
      id: 3,
      nom: "Sèna Kpossou",
      photo: "/placeholder.svg?height=100&width=100",
      note: 4.9,
      avis: 256,
      whatsapp: "+22995000003",
      lat: 6.3628,
      lng: 2.4264,
      produits: 42,
      membres_depuis: "2021",
    },
  },
]

type Produit = (typeof PRODUITS_INITIAUX)[0]
type Message = { id: number; texte: string; envoyeur: "acheteur" | "vendeur"; timestamp: Date }
type Vue = "accueil" | "vendre" | "chat" | "profil" | "mon-profil" | "inscription" | "connexion"
type TypeCompte = "acheteur" | "vendeur" | null
type EtapeInscription = "type" | "infos" | "produit" | "verification" | "termine"

interface Utilisateur {
  id: number
  nom: string
  prenom: string
  telephone: string
  dateNaissance: string
  sexe: "homme" | "femme"
  photo: string
  typeCompte: TypeCompte
  whatsapp: string
  note: number
  avis: number
  produits: number
  membres_depuis: string
  ville: string
  lat: number
  lng: number
  nomProduit?: string
  categorieProduit?: string
}

export default function Axitche() {
  // États d'authentification
  const [estConnecte, setEstConnecte] = useState(false)
  const [utilisateur, setUtilisateur] = useState<Utilisateur | null>(null)
  const [etapeInscription, setEtapeInscription] = useState<EtapeInscription>("type")
  const [afficherMdp, setAfficherMdp] = useState(false)

  // Formulaire d'inscription
  const [formInscription, setFormInscription] = useState({
    typeCompte: null as TypeCompte,
    nom: "",
    prenom: "",
    telephone: "",
    dateNaissance: "",
    sexe: "homme" as "homme" | "femme",
    motDePasse: "",
    confirmerMdp: "",
    codeVerification: "",
    nomProduit: "",
    categorieProduit: "artisanat",
  })

  // Formulaire de connexion
  const [formConnexion, setFormConnexion] = useState({
    telephone: "",
    motDePasse: "",
  })

  const [vue, setVue] = useState<Vue>("inscription")
  const [produits, setProduits] = useState(PRODUITS_INITIAUX)
  const [produitSelectionne, setProduitSelectionne] = useState<Produit | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [nouveauMessage, setNouveauMessage] = useState("")
  const [messageBloque, setMessageBloque] = useState(false)
  const [categorieActive, setCategorieActive] = useState("tous")
  const [recherche, setRecherche] = useState("")
  const [afficherCategories, setAfficherCategories] = useState(false)
  const [erreurConnexion, setErreurConnexion] = useState("")
  const [afficherPartage, setAfficherPartage] = useState(false)
  const [lienCopie, setLienCopie] = useState(false)
  const [appUrl, setAppUrl] = useState("")

  // Recuperer l'URL de l'application
  useEffect(() => {
    if (typeof window !== "undefined") {
      setAppUrl(window.location.origin)
    }
  }, [])

  // Copier le lien
  const copierLien = async () => {
    try {
      await navigator.clipboard.writeText(appUrl)
      setLienCopie(true)
      setTimeout(() => setLienCopie(false), 2000)
    } catch (err) {
      console.error("Erreur lors de la copie")
    }
  }

  // Partager l'application
  const partagerApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "AXITCHE - Marche Local du Benin",
          text: "Decouvre AXITCHE, l'application pour acheter et vendre des produits locaux au Benin!",
          url: appUrl,
        })
      } catch (err) {
        setAfficherPartage(true)
      }
    } else {
      setAfficherPartage(true)
    }
  }

  // États pour le formulaire de vente
  const [nouveauProduit, setNouveauProduit] = useState({
    titre: "",
    prix: "",
    whatsapp: "",
    categorie: "artisanat",
  })
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [gpsCharge, setGpsCharge] = useState(false)
  const [position, setPosition] = useState<{ lat: number; lng: number } | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Filtrer les produits
  const produitsFiltres = produits.filter((p) => {
    const matchCategorie = categorieActive === "tous" || p.categorie === categorieActive
    const matchRecherche = p.titre.toLowerCase().includes(recherche.toLowerCase())
    return matchCategorie && matchRecherche
  })

  // Fonction pour verifier les mots interdits et contenus suspects
  const contientMotInterdit = (texte: string): { interdit: boolean; raison: string } => {
    const texteLower = texte.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    
    // Verifier les mots interdits
    for (const mot of MOTS_INTERDITS) {
      const motNormalise = mot.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      if (texteLower.includes(motNormalise)) {
        if (["bb", "bebe", "amour", "cheri", "cherie", "doudou", "ma puce", "mon ange", "belle", "beaute", "crush", "date", "rdv", "rencontre", "je te kiffe", "kiffe", "tu me plais"].some(m => motNormalise.includes(m))) {
          return { interdit: true, raison: "Ce message contient du contenu de drague/seduction. AXITCHE est reserve aux affaires uniquement." }
        }
        if (["sexe", "sexy", "nue", "nude", "porn", "coucher", "baiser", "intime", "coquin", "hot", "chaud", "desir", "excite"].some(m => motNormalise.includes(m))) {
          return { interdit: true, raison: "Contenu a caractere sexuel interdit. Votre compte peut etre suspendu." }
        }
        if (["arnaque", "gratuit", "argent facile", "bitcoin", "investissement", "benefice", "million", "carte bancaire", "virement", "western union", "heritage", "loterie"].some(m => motNormalise.includes(m))) {
          return { interdit: true, raison: "Message suspect detecte (potentielle arnaque). Ce type de message est interdit." }
        }
        return { interdit: true, raison: "Ce message enfreint nos regles d'utilisation. Seuls les echanges commerciaux sont autorises." }
      }
    }
    
    // Verifier les patterns suspects
    for (const pattern of PATTERNS_SUSPECTS) {
      if (pattern.test(texte)) {
        return { interdit: true, raison: "Les liens, emails et numeros de telephone ne sont pas autorises dans le chat. Utilisez le bouton WhatsApp." }
      }
    }
    
    return { interdit: false, raison: "" }
  }

  // Etat pour afficher la raison du blocage
  const [raisonBlocage, setRaisonBlocage] = useState("")

  // Envoyer un message
  const envoyerMessage = () => {
    if (!nouveauMessage.trim()) return

    const verification = contientMotInterdit(nouveauMessage)
    if (verification.interdit) {
      setMessageBloque(true)
      setRaisonBlocage(verification.raison)
      setTimeout(() => {
        setMessageBloque(false)
        setRaisonBlocage("")
      }, 5000)
      return
    }

    const message: Message = {
      id: Date.now(),
      texte: nouveauMessage,
      envoyeur: "acheteur",
      timestamp: new Date(),
    }
    setMessages([...messages, message])
    setNouveauMessage("")

    // Simulation réponse vendeur
    setTimeout(() => {
      const reponses = [
        "Merci pour votre intérêt ! Le prix est négociable.",
        "Oui, le produit est toujours disponible.",
        "Je peux faire un petit effort sur le prix si vous venez aujourd'hui.",
        "D'accord, passez au marché demain matin.",
      ]
      const reponseVendeur: Message = {
        id: Date.now() + 1,
        texte: reponses[Math.floor(Math.random() * reponses.length)],
        envoyeur: "vendeur",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, reponseVendeur])
    }, 1500)
  }

  // Ouvrir le chat avec un produit
  const ouvrirNegociation = (produit: Produit) => {
    setProduitSelectionne(produit)
    setMessages([
      {
        id: 1,
        texte: `Bonjour ! Je suis intéressé(e) par "${produit.titre}" à ${produit.prix.toLocaleString()} FCFA. Est-ce négociable ?`,
        envoyeur: "acheteur",
        timestamp: new Date(),
      },
      {
        id: 2,
        texte: `Bonjour et bienvenue ! Oui, on peut discuter du prix. Qu'est-ce que vous proposez ?`,
        envoyeur: "vendeur",
        timestamp: new Date(),
      },
    ])
    setVue("chat")
  }

  // Voir le profil du vendeur
  const voirProfil = (produit: Produit) => {
    setProduitSelectionne(produit)
    setVue("profil")
  }

  // Géolocalisation
  const obtenirPosition = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setPosition({ lat: pos.coords.latitude, lng: pos.coords.longitude })
          setGpsCharge(true)
        },
        () => {
          setPosition({ lat: 6.3654, lng: 2.4183 })
          setGpsCharge(true)
        }
      )
    } else {
      setPosition({ lat: 6.3654, lng: 2.4183 })
      setGpsCharge(true)
    }
  }

  // Gérer l'upload d'image
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  // Publier un produit
  const publierProduit = () => {
    if (!nouveauProduit.titre || !nouveauProduit.prix || !imagePreview || !position || !utilisateur) return

    const produit: Produit = {
      id: Date.now(),
      titre: nouveauProduit.titre,
      prix: parseInt(nouveauProduit.prix),
      ville: utilisateur.ville,
      categorie: nouveauProduit.categorie,
      image: imagePreview,
      vendeur: {
        id: utilisateur.id,
        nom: `${utilisateur.prenom} ${utilisateur.nom}`,
        photo: utilisateur.photo,
        note: utilisateur.note,
        avis: utilisateur.avis,
        whatsapp: nouveauProduit.whatsapp || utilisateur.whatsapp,
        lat: position.lat,
        lng: position.lng,
        produits: utilisateur.produits + 1,
        membres_depuis: utilisateur.membres_depuis,
      },
    }

    setProduits([produit, ...produits])
    setNouveauProduit({ titre: "", prix: "", whatsapp: "", categorie: "artisanat" })
    setImagePreview(null)
    setGpsCharge(false)
    setPosition(null)
    setVue("accueil")
  }

  // Ouvrir Google Maps itinéraire
  const ouvrirItineraire = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, "_blank")
  }

  // Appeler WhatsApp
  const contacterWhatsApp = (whatsapp: string, titre?: string) => {
    const message = encodeURIComponent(titre ? `Bonjour, je suis intéressé par "${titre}" sur AXITCHÉ` : "Bonjour, je vous contacte via AXITCHÉ")
    window.open(`https://wa.me/${whatsapp.replace("+", "")}?text=${message}`, "_blank")
  }

  const getCategorieNom = (id: string) => CATEGORIES.find((c) => c.id === id)?.nom || id

  // Gérer l'inscription
  const handleInscription = () => {
    if (etapeInscription === "type" && formInscription.typeCompte) {
      setEtapeInscription("infos")
    } else if (etapeInscription === "infos") {
      if (formInscription.nom && formInscription.prenom && formInscription.telephone && formInscription.motDePasse) {
        if (formInscription.motDePasse !== formInscription.confirmerMdp) {
          return
        }
        if (formInscription.typeCompte === "vendeur") {
          setEtapeInscription("produit")
        } else {
          setEtapeInscription("verification")
        }
      }
    } else if (etapeInscription === "produit") {
      if (formInscription.nomProduit && formInscription.categorieProduit) {
        setEtapeInscription("verification")
      }
    } else if (etapeInscription === "verification") {
      if (formInscription.codeVerification.length === 6) {
        // Créer l'utilisateur
        const nouvelUtilisateur: Utilisateur = {
          id: Date.now(),
          nom: formInscription.nom,
          prenom: formInscription.prenom,
          telephone: formInscription.telephone,
          dateNaissance: formInscription.dateNaissance,
          sexe: formInscription.sexe,
          photo: "/placeholder.svg?height=100&width=100",
          typeCompte: formInscription.typeCompte,
          whatsapp: formInscription.telephone,
          note: 5.0,
          avis: 0,
          produits: 0,
          membres_depuis: new Date().getFullYear().toString(),
          ville: "Cotonou",
          lat: 6.3654,
          lng: 2.4183,
          nomProduit: formInscription.nomProduit,
          categorieProduit: formInscription.categorieProduit,
        }
        setUtilisateur(nouvelUtilisateur)
        setEstConnecte(true)
        setEtapeInscription("termine")
        setTimeout(() => {
          setVue("accueil")
        }, 2000)
      }
    }
  }

  // Gérer la connexion
  const handleConnexion = () => {
    if (formConnexion.telephone && formConnexion.motDePasse) {
      // Simulation de connexion
      const utilisateurConnecte: Utilisateur = {
        id: Date.now(),
        nom: "Dossou",
        prenom: "Jean",
        telephone: formConnexion.telephone,
        dateNaissance: "1990-01-01",
        sexe: "homme",
        photo: "/placeholder.svg?height=100&width=100",
        typeCompte: "vendeur",
        whatsapp: formConnexion.telephone,
        note: 4.7,
        avis: 45,
        produits: 12,
        membres_depuis: "2024",
        ville: "Cotonou",
        lat: 6.3654,
        lng: 2.4183,
      }
      setUtilisateur(utilisateurConnecte)
      setEstConnecte(true)
      setVue("accueil")
    } else {
      setErreurConnexion("Veuillez remplir tous les champs")
    }
  }

  // Déconnexion
  const handleDeconnexion = () => {
    setEstConnecte(false)
    setUtilisateur(null)
    setVue("inscription")
    setEtapeInscription("type")
    setFormInscription({
      typeCompte: null,
      nom: "",
      prenom: "",
      telephone: "",
      dateNaissance: "",
      sexe: "homme",
      motDePasse: "",
      confirmerMdp: "",
      codeVerification: "",
      nomProduit: "",
      categorieProduit: "artisanat",
    })
  }

  // PAGE D'INSCRIPTION
  if (vue === "inscription") {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-white flex flex-col">
        {/* Header */}
        <header className="px-4 py-6 text-center">
          <h1 className="text-3xl font-bold">
            <span className="text-[#00FF88]">AXIT</span>CHÉ
          </h1>
          <p className="text-gray-400 text-sm mt-1">Le marché local du Bénin</p>
        </header>

        <main className="flex-1 px-4 pb-8">
          {/* Étape 1: Choix du type de compte */}
          {etapeInscription === "type" && (
            <div className="space-y-6 max-w-md mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-xl font-semibold mb-2">Créer un compte</h2>
                <p className="text-gray-400 text-sm">Choisissez votre type de compte</p>
              </div>

              <div className="space-y-4">
                <button
                  onClick={() => setFormInscription({ ...formInscription, typeCompte: "acheteur" })}
                  className={`w-full p-5 rounded-2xl border-2 transition flex items-center gap-4 ${
                    formInscription.typeCompte === "acheteur"
                      ? "border-[#00FF88] bg-[#00FF88]/10"
                      : "border-gray-800 bg-[#1A1A1A] hover:border-gray-700"
                  }`}
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center ${
                    formInscription.typeCompte === "acheteur" ? "bg-[#00FF88]" : "bg-[#252525]"
                  }`}>
                    <ShoppingBag className={`w-7 h-7 ${formInscription.typeCompte === "acheteur" ? "text-black" : "text-gray-400"}`} />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold text-lg">Acheteur</h3>
                    <p className="text-sm text-gray-400">Je veux acheter des produits</p>
                  </div>
                  {formInscription.typeCompte === "acheteur" && (
                    <div className="w-6 h-6 bg-[#00FF88] rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}
                </button>

                <button
                  onClick={() => setFormInscription({ ...formInscription, typeCompte: "vendeur" })}
                  className={`w-full p-5 rounded-2xl border-2 transition flex items-center gap-4 ${
                    formInscription.typeCompte === "vendeur"
                      ? "border-[#00FF88] bg-[#00FF88]/10"
                      : "border-gray-800 bg-[#1A1A1A] hover:border-gray-700"
                  }`}
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center ${
                    formInscription.typeCompte === "vendeur" ? "bg-[#00FF88]" : "bg-[#252525]"
                  }`}>
                    <Store className={`w-7 h-7 ${formInscription.typeCompte === "vendeur" ? "text-black" : "text-gray-400"}`} />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold text-lg">Vendeur</h3>
                    <p className="text-sm text-gray-400">Je veux vendre mes produits</p>
                  </div>
                  {formInscription.typeCompte === "vendeur" && (
                    <div className="w-6 h-6 bg-[#00FF88] rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}
                </button>
              </div>

              <button
                onClick={handleInscription}
                disabled={!formInscription.typeCompte}
                className="w-full bg-[#00FF88] text-black font-semibold py-4 rounded-xl hover:bg-[#00DD77] transition disabled:opacity-50 disabled:cursor-not-allowed mt-6"
              >
                Continuer
              </button>

              <div className="text-center mt-6">
                <p className="text-gray-400 text-sm">
                  Vous avez deja un compte ?{" "}
                  <button onClick={() => setVue("connexion")} className="text-[#00FF88] font-semibold hover:underline">
                    Se connecter
                  </button>
                </p>
              </div>

              {/* Bouton partager l'app */}
              <button
                onClick={() => setAfficherPartage(true)}
                className="w-full flex items-center justify-center gap-2 mt-4 py-3 border border-[#00FF88]/30 rounded-xl text-[#00FF88] hover:bg-[#00FF88]/10 transition"
              >
                <Share2 className="w-5 h-5" />
                <span className="font-medium">Partager AXITCHE</span>
              </button>
            </div>
          )}

          {/* Etape 2: Informations personnelles (style Facebook) */}
          {etapeInscription === "infos" && (
            <div className="space-y-4 max-w-md mx-auto">
              <button onClick={() => setEtapeInscription("type")} className="flex items-center gap-2 text-gray-400 hover:text-white mb-4">
                <ChevronLeft className="w-5 h-5" />
                Retour
              </button>

              <div className="text-center mb-6">
                <h2 className="text-xl font-semibold mb-2">Vos informations</h2>
                <p className="text-gray-400 text-sm">Entrez vos données personnelles</p>
              </div>

              <div className="space-y-4">
                {/* Prénom */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Prénom</label>
                  <input
                    type="text"
                    value={formInscription.prenom}
                    onChange={(e) => setFormInscription({ ...formInscription, prenom: e.target.value })}
                    placeholder="Votre prénom"
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                  />
                </div>

                {/* Nom */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Nom de famille</label>
                  <input
                    type="text"
                    value={formInscription.nom}
                    onChange={(e) => setFormInscription({ ...formInscription, nom: e.target.value })}
                    placeholder="Votre nom"
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                  />
                </div>

                {/* Téléphone */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Numéro de téléphone</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="tel"
                      value={formInscription.telephone}
                      onChange={(e) => setFormInscription({ ...formInscription, telephone: e.target.value })}
                      placeholder="+229 XX XX XX XX"
                      className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Date de naissance */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Date de naissance</label>
                  <div className="relative">
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="date"
                      value={formInscription.dateNaissance}
                      onChange={(e) => setFormInscription({ ...formInscription, dateNaissance: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Sexe */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Sexe</label>
                  <div className="flex gap-4">
                    <button
                      onClick={() => setFormInscription({ ...formInscription, sexe: "homme" })}
                      className={`flex-1 py-3 rounded-xl border-2 transition ${
                        formInscription.sexe === "homme"
                          ? "border-[#00FF88] bg-[#00FF88]/10 text-white"
                          : "border-gray-800 bg-[#1A1A1A] text-gray-400"
                      }`}
                    >
                      Homme
                    </button>
                    <button
                      onClick={() => setFormInscription({ ...formInscription, sexe: "femme" })}
                      className={`flex-1 py-3 rounded-xl border-2 transition ${
                        formInscription.sexe === "femme"
                          ? "border-[#00FF88] bg-[#00FF88]/10 text-white"
                          : "border-gray-800 bg-[#1A1A1A] text-gray-400"
                      }`}
                    >
                      Femme
                    </button>
                  </div>
                </div>

                {/* Mot de passe */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Mot de passe</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type={afficherMdp ? "text" : "password"}
                      value={formInscription.motDePasse}
                      onChange={(e) => setFormInscription({ ...formInscription, motDePasse: e.target.value })}
                      placeholder="Minimum 6 caractères"
                      className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-12 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setAfficherMdp(!afficherMdp)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500"
                    >
                      {afficherMdp ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Confirmer mot de passe */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Confirmer le mot de passe</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type={afficherMdp ? "text" : "password"}
                      value={formInscription.confirmerMdp}
                      onChange={(e) => setFormInscription({ ...formInscription, confirmerMdp: e.target.value })}
                      placeholder="Répétez le mot de passe"
                      className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                    />
                  </div>
                  {formInscription.confirmerMdp && formInscription.motDePasse !== formInscription.confirmerMdp && (
                    <p className="text-red-400 text-xs mt-1">Les mots de passe ne correspondent pas</p>
                  )}
                </div>
              </div>

              {/* Regles de la plateforme */}
              <div className="bg-[#1A1A1A] border border-gray-800 rounded-xl p-4 mt-4">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-[#00FF88] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white font-semibold text-sm">Regles AXITCHE</p>
                    <ul className="text-gray-400 text-xs mt-2 space-y-1">
                      <li>- Aucune photo de nudite ou contenu explicite</li>
                      <li>- Aucun message de drague, seduction ou arnaque</li>
                      <li>- Echanges commerciaux uniquement</li>
                      <li>- Respect obligatoire entre utilisateurs</li>
                    </ul>
                    <p className="text-red-400 text-[10px] mt-2">Tout manquement = suspension immediate du compte</p>
                  </div>
                </div>
              </div>

              <button
                onClick={handleInscription}
                disabled={!formInscription.nom || !formInscription.prenom || !formInscription.telephone || !formInscription.motDePasse || formInscription.motDePasse !== formInscription.confirmerMdp}
                className="w-full bg-[#00FF88] text-black font-semibold py-4 rounded-xl hover:bg-[#00DD77] transition disabled:opacity-50 disabled:cursor-not-allowed mt-6"
              >
                Accepter et continuer
              </button>
            </div>
          )}

          {/* Etape 3: Informations produit (pour vendeurs) */}
          {etapeInscription === "produit" && (
            <div className="space-y-4 max-w-md mx-auto">
              <button onClick={() => setEtapeInscription("infos")} className="flex items-center gap-2 text-gray-400 hover:text-white mb-4">
                <ChevronLeft className="w-5 h-5" />
                Retour
              </button>

              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-[#00FF88]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Store className="w-8 h-8 text-[#00FF88]" />
                </div>
                <h2 className="text-xl font-semibold mb-2">Votre activité</h2>
                <p className="text-gray-400 text-sm">Décrivez ce que vous vendez</p>
              </div>

              <div className="space-y-4">
                {/* Nom du produit */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Nom de votre produit/service</label>
                  <input
                    type="text"
                    value={formInscription.nomProduit}
                    onChange={(e) => setFormInscription({ ...formInscription, nomProduit: e.target.value })}
                    placeholder="Ex: Tissus traditionnels, Tomates fraiches..."
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                  />
                </div>

                {/* Catégorie */}
                <div>
                  <label className="block text-sm text-gray-400 mb-3">Catégorie de marché</label>
                  <div className="grid grid-cols-3 gap-2 max-h-64 overflow-y-auto pr-2">
                    {CATEGORIES.filter(c => c.id !== "tous").map((cat) => {
                      const Icon = cat.icon
                      return (
                        <button
                          key={cat.id}
                          onClick={() => setFormInscription({ ...formInscription, categorieProduit: cat.id })}
                          className={`flex flex-col items-center gap-1 p-3 rounded-xl transition ${
                            formInscription.categorieProduit === cat.id
                              ? "bg-[#00FF88]/20 border-2 border-[#00FF88]"
                              : "bg-[#1A1A1A] border-2 border-transparent hover:border-gray-700"
                          }`}
                        >
                          <div
                            className="w-10 h-10 rounded-full flex items-center justify-center"
                            style={{ backgroundColor: `${cat.couleur}20` }}
                          >
                            <Icon className="w-5 h-5" style={{ color: cat.couleur }} />
                          </div>
                          <span className="text-[10px] text-center text-gray-300 line-clamp-1">{cat.nom}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>
              </div>

              <button
                onClick={handleInscription}
                disabled={!formInscription.nomProduit || !formInscription.categorieProduit}
                className="w-full bg-[#00FF88] text-black font-semibold py-4 rounded-xl hover:bg-[#00DD77] transition disabled:opacity-50 disabled:cursor-not-allowed mt-6"
              >
                Continuer
              </button>
            </div>
          )}

          {/* Étape 4: Vérification SMS */}
          {etapeInscription === "verification" && (
            <div className="space-y-4 max-w-md mx-auto">
              <button onClick={() => setEtapeInscription(formInscription.typeCompte === "vendeur" ? "produit" : "infos")} className="flex items-center gap-2 text-gray-400 hover:text-white mb-4">
                <ChevronLeft className="w-5 h-5" />
                Retour
              </button>

              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-[#00FF88]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ShieldCheck className="w-8 h-8 text-[#00FF88]" />
                </div>
                <h2 className="text-xl font-semibold mb-2">Vérification</h2>
                <p className="text-gray-400 text-sm">
                  Un code a été envoyé au<br />
                  <span className="text-white font-medium">{formInscription.telephone}</span>
                </p>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2 text-center">Entrez le code à 6 chiffres</label>
                <input
                  type="text"
                  value={formInscription.codeVerification}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, "").slice(0, 6)
                    setFormInscription({ ...formInscription, codeVerification: val })
                  }}
                  placeholder="000000"
                  maxLength={6}
                  className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl px-4 py-4 text-white text-center text-2xl tracking-[0.5em] placeholder-gray-600 focus:border-[#00FF88] focus:outline-none"
                />
              </div>

              <p className="text-center text-gray-400 text-sm">
                {"Vous n'avez pas reçu le code ?"}{" "}
                <button className="text-[#00FF88] font-semibold hover:underline">Renvoyer</button>
              </p>

              <p className="text-center text-gray-500 text-xs mt-2">
                Pour le test, entrez: <span className="text-[#00FF88]">123456</span>
              </p>

              <button
                onClick={handleInscription}
                disabled={formInscription.codeVerification.length !== 6}
                className="w-full bg-[#00FF88] text-black font-semibold py-4 rounded-xl hover:bg-[#00DD77] transition disabled:opacity-50 disabled:cursor-not-allowed mt-6"
              >
                Vérifier
              </button>
            </div>
          )}

          {/* Étape 5: Inscription terminée */}
          {etapeInscription === "termine" && (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
              <div className="w-20 h-20 bg-[#00FF88] rounded-full flex items-center justify-center mb-6 animate-bounce">
                <Check className="w-10 h-10 text-black" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Bienvenue sur AXITCHÉ !</h2>
              <p className="text-gray-400">
                {formInscription.typeCompte === "vendeur" 
                  ? "Votre compte vendeur est prêt. Commencez à vendre !" 
                  : "Votre compte est prêt. Découvrez le marché !"}
              </p>
            </div>
          )}
        </main>
      </div>
    )
  }

  // PAGE DE CONNEXION
  if (vue === "connexion") {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-white flex flex-col">
        {/* Header */}
        <header className="px-4 py-6 text-center">
          <h1 className="text-3xl font-bold">
            <span className="text-[#00FF88]">AXIT</span>CHÉ
          </h1>
          <p className="text-gray-400 text-sm mt-1">Le marché local du Bénin</p>
        </header>

        <main className="flex-1 px-4 pb-8">
          <div className="space-y-4 max-w-md mx-auto">
            <button onClick={() => setVue("inscription")} className="flex items-center gap-2 text-gray-400 hover:text-white mb-4">
              <ChevronLeft className="w-5 h-5" />
              Retour
            </button>

            <div className="text-center mb-6">
              <h2 className="text-xl font-semibold mb-2">Connexion</h2>
              <p className="text-gray-400 text-sm">Connectez-vous à votre compte</p>
            </div>

            {erreurConnexion && (
              <div className="bg-red-500/20 border border-red-500 rounded-xl p-3 text-red-400 text-sm text-center">
                {erreurConnexion}
              </div>
            )}

            <div className="space-y-4">
              {/* Téléphone */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">Numéro de téléphone</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="tel"
                    value={formConnexion.telephone}
                    onChange={(e) => setFormConnexion({ ...formConnexion, telephone: e.target.value })}
                    placeholder="+229 XX XX XX XX"
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                  />
                </div>
              </div>

              {/* Mot de passe */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">Mot de passe</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type={afficherMdp ? "text" : "password"}
                    value={formConnexion.motDePasse}
                    onChange={(e) => setFormConnexion({ ...formConnexion, motDePasse: e.target.value })}
                    placeholder="Votre mot de passe"
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-12 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setAfficherMdp(!afficherMdp)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500"
                  >
                    {afficherMdp ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <button className="text-[#00FF88] text-sm hover:underline text-right w-full">
                Mot de passe oublié ?
              </button>
            </div>

            <button
              onClick={handleConnexion}
              className="w-full bg-[#00FF88] text-black font-semibold py-4 rounded-xl hover:bg-[#00DD77] transition mt-6"
            >
              Se connecter
            </button>

            <div className="text-center mt-6">
              <p className="text-gray-400 text-sm">
                {"Vous n'avez pas de compte ?"}{" "}
                <button onClick={() => setVue("inscription")} className="text-[#00FF88] font-semibold hover:underline">
                  {"S'inscrire"}
                </button>
              </p>
            </div>
          </div>
        </main>
      </div>
    )
  }

  // APPLICATION PRINCIPALE (après connexion)
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#0A0A0A]/95 backdrop-blur border-b border-[#00FF88]/20 px-4 py-3">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">
            <span className="text-[#00FF88]">AXIT</span>CHÉ
          </h1>
          <div className="flex items-center gap-3">
            <button className="relative p-2 hover:bg-[#1A1A1A] rounded-full transition">
              <Bell className="w-5 h-5 text-gray-400" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#00FF88] rounded-full"></span>
            </button>
          </div>
        </div>
      </header>

      {/* Contenu principal */}
      <main className="pb-24 px-4 pt-4">
        {/* VUE ACCUEIL - MARCHÉ */}
        {vue === "accueil" && (
          <div className="space-y-4">
            {/* Barre de recherche */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                placeholder="Rechercher un produit..."
                value={recherche}
                onChange={(e) => setRecherche(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-12 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
              />
              <button
                onClick={() => setAfficherCategories(!afficherCategories)}
                className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition ${afficherCategories ? "bg-[#00FF88] text-black" : "text-gray-400 hover:text-white"}`}
              >
                <Filter className="w-5 h-5" />
              </button>
            </div>

            {/* Grille des catégories */}
            {afficherCategories && (
              <div className="bg-[#1A1A1A] rounded-2xl p-4 border border-gray-800">
                <h3 className="text-sm font-semibold text-[#00FF88] mb-3">Catégories de marché</h3>
                <div className="grid grid-cols-4 gap-3">
                  {CATEGORIES.map((cat) => {
                    const Icon = cat.icon
                    return (
                      <button
                        key={cat.id}
                        onClick={() => {
                          setCategorieActive(cat.id)
                          setAfficherCategories(false)
                        }}
                        className={`flex flex-col items-center gap-1 p-3 rounded-xl transition ${
                          categorieActive === cat.id ? "bg-[#00FF88]/20 border border-[#00FF88]" : "bg-[#0A0A0A] hover:bg-[#252525]"
                        }`}
                      >
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center"
                          style={{ backgroundColor: `${cat.couleur}20` }}
                        >
                          <Icon className="w-5 h-5" style={{ color: cat.couleur }} />
                        </div>
                        <span className="text-[10px] text-center text-gray-300 line-clamp-1">{cat.nom}</span>
                      </button>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Catégorie active */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Store className="w-5 h-5 text-[#00FF88]" />
                <h2 className="text-lg font-semibold">
                  {categorieActive === "tous" ? "Tous les produits" : getCategorieNom(categorieActive)}
                </h2>
              </div>
              <span className="text-sm text-gray-400">{produitsFiltres.length} articles</span>
            </div>

            {/* Chips catégories rapides */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {CATEGORIES.slice(0, 8).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategorieActive(cat.id)}
                  className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition ${
                    categorieActive === cat.id
                      ? "bg-[#00FF88] text-black"
                      : "bg-[#1A1A1A] text-gray-300 hover:bg-[#252525]"
                  }`}
                >
                  {cat.nom}
                </button>
              ))}
            </div>

            {/* Grille produits */}
            <div className="grid grid-cols-2 gap-3">
              {produitsFiltres.map((produit) => (
                <div key={produit.id} className="bg-[#1A1A1A] rounded-2xl overflow-hidden border border-gray-800">
                  <div className="aspect-square relative">
                    <img src={produit.image} alt={produit.titre} className="w-full h-full object-cover" />
                    <div className="absolute top-2 right-2 bg-[#00FF88] text-black text-xs font-bold px-2 py-1 rounded-full">
                      {produit.prix.toLocaleString()} F
                    </div>
                    <div className="absolute top-2 left-2 bg-black/60 text-white text-[10px] px-2 py-1 rounded-full">
                      {getCategorieNom(produit.categorie)}
                    </div>
                  </div>
                  <div className="p-3 space-y-2">
                    <h3 className="font-medium text-sm line-clamp-2">{produit.titre}</h3>
                    <div className="flex items-center gap-1 text-gray-400 text-xs">
                      <MapPin className="w-3 h-3" />
                      <span>{produit.ville}</span>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-400 text-xs">
                      <Star className="w-3 h-3 fill-current" />
                      <span>{produit.vendeur.note}</span>
                      <span className="text-gray-500">• {produit.vendeur.nom}</span>
                    </div>
                    <div className="flex gap-2 pt-1">
                      <button
                        onClick={() => ouvrirNegociation(produit)}
                        className="flex-1 bg-[#00FF88] text-black text-xs font-semibold py-2 rounded-xl hover:bg-[#00DD77] transition"
                      >
                        Négocier
                      </button>
                      <button
                        onClick={() => voirProfil(produit)}
                        className="p-2 border border-[#00FF88]/30 rounded-xl hover:bg-[#00FF88]/10 transition"
                      >
                        <User className="w-4 h-4 text-[#00FF88]" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {produitsFiltres.length === 0 && (
              <div className="text-center py-12">
                <ShoppingBag className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-400">Aucun produit trouvé</p>
                <p className="text-gray-500 text-sm">Essayez une autre catégorie</p>
              </div>
            )}
          </div>
        )}

        {/* VUE VENDRE */}
        {vue === "vendre" && (
          <div className="space-y-6 max-w-md mx-auto">
            <h2 className="text-xl font-semibold text-[#00FF88]">Vendre un produit</h2>

            {/* Upload photo */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="aspect-square bg-[#1A1A1A] rounded-2xl border-2 border-dashed border-[#00FF88]/30 flex flex-col items-center justify-center cursor-pointer hover:border-[#00FF88]/50 transition overflow-hidden"
            >
              {imagePreview ? (
                <div className="relative w-full h-full">
                  <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setImagePreview(null)
                    }}
                    className="absolute top-2 right-2 bg-red-500 p-1 rounded-full"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <>
                  <Camera className="w-12 h-12 text-[#00FF88]/50 mb-2" />
                  <p className="text-sm text-gray-400">Prendre une photo du produit</p>
                  <p className="text-xs text-gray-500">ou choisir dans la galerie</p>
                </>
              )}
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={handleImageUpload} className="hidden" />

            {/* Alerte photos interdites */}
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3">
              <div className="flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-red-400 text-xs font-semibold">Photos interdites</p>
                  <p className="text-red-300/70 text-[10px] mt-1">
                    Nudite, contenu explicite ou inapproprie = suspension immediate du compte. Seules les photos de produits sont autorisees.
                  </p>
                </div>
              </div>
            </div>

            {/* Titre */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Nom du produit</label>
              <input
                type="text"
                value={nouveauProduit.titre}
                onChange={(e) => setNouveauProduit({ ...nouveauProduit, titre: e.target.value })}
                placeholder="Ex: Tissus Kente authentique"
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
              />
            </div>

            {/* Prix */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Prix (FCFA)</label>
              <input
                type="number"
                value={nouveauProduit.prix}
                onChange={(e) => setNouveauProduit({ ...nouveauProduit, prix: e.target.value })}
                placeholder="Ex: 15000"
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
              />
            </div>

            {/* Catégorie */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Catégorie</label>
              <div className="grid grid-cols-4 gap-2 max-h-48 overflow-y-auto">
                {CATEGORIES.filter((c) => c.id !== "tous").map((cat) => {
                  const Icon = cat.icon
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setNouveauProduit({ ...nouveauProduit, categorie: cat.id })}
                      className={`flex flex-col items-center gap-1 p-2 rounded-xl transition ${
                        nouveauProduit.categorie === cat.id ? "bg-[#00FF88]/20 border border-[#00FF88]" : "bg-[#1A1A1A] hover:bg-[#252525]"
                      }`}
                    >
                      <Icon className="w-5 h-5" style={{ color: cat.couleur }} />
                      <span className="text-[9px] text-center text-gray-300 line-clamp-1">{cat.nom}</span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* WhatsApp */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Numéro WhatsApp</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="tel"
                  value={nouveauProduit.whatsapp}
                  onChange={(e) => setNouveauProduit({ ...nouveauProduit, whatsapp: e.target.value })}
                  placeholder={utilisateur?.whatsapp || "+229 XX XX XX XX"}
                  className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
                />
              </div>
            </div>

            {/* GPS */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Localisation</label>
              <button
                onClick={obtenirPosition}
                className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl border transition ${
                  gpsCharge ? "bg-[#00FF88]/20 border-[#00FF88] text-[#00FF88]" : "border-gray-800 text-gray-400 hover:border-gray-700"
                }`}
              >
                <Navigation className="w-5 h-5" />
                {gpsCharge ? "Position obtenue" : "Obtenir ma position GPS"}
              </button>
            </div>

            {/* Bouton publier */}
            <button
              onClick={publierProduit}
              disabled={!nouveauProduit.titre || !nouveauProduit.prix || !imagePreview || !gpsCharge}
              className="w-full bg-[#00FF88] text-black font-semibold py-4 rounded-xl hover:bg-[#00DD77] transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Publier le produit
            </button>
          </div>
        )}

        {/* VUE CHAT */}
        {vue === "chat" && produitSelectionne && (
          <div className="flex flex-col h-[calc(100vh-180px)]">
            {/* En-tête du chat */}
            <div className="flex items-center gap-3 pb-4 border-b border-gray-800">
              <button onClick={() => setVue("accueil")} className="p-2 hover:bg-[#1A1A1A] rounded-full">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <img src={produitSelectionne.vendeur.photo} alt={produitSelectionne.vendeur.nom} className="w-10 h-10 rounded-full object-cover" />
              <div className="flex-1">
                <h3 className="font-semibold text-sm">{produitSelectionne.vendeur.nom}</h3>
                <p className="text-xs text-gray-400">{produitSelectionne.titre}</p>
              </div>
              <button onClick={() => voirProfil(produitSelectionne)} className="p-2 hover:bg-[#1A1A1A] rounded-full">
                <User className="w-5 h-5 text-[#00FF88]" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto py-4 space-y-3">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.envoyeur === "acheteur" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] px-4 py-2 rounded-2xl ${
                      msg.envoyeur === "acheteur" ? "bg-[#00FF88] text-black rounded-br-none" : "bg-[#1A1A1A] text-white rounded-bl-none"
                    }`}
                  >
                    <p className="text-sm">{msg.texte}</p>
                    <p className={`text-[10px] mt-1 ${msg.envoyeur === "acheteur" ? "text-black/60" : "text-gray-500"}`}>
                      {msg.timestamp.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Alerte message bloque avec raison detaillee */}
            {messageBloque && (
              <div className="bg-red-500/20 border border-red-500 rounded-xl p-4 mb-2">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-red-500/30 rounded-full flex items-center justify-center flex-shrink-0">
                    <ShieldCheck className="w-4 h-4 text-red-400" />
                  </div>
                  <div>
                    <p className="text-red-400 font-semibold text-sm">Message bloque</p>
                    <p className="text-red-300/80 text-xs mt-1">{raisonBlocage}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Rappel des regles */}
            <div className="bg-[#1A1A1A] border border-gray-800 rounded-xl p-3 mb-2">
              <p className="text-gray-400 text-xs text-center">
                <ShieldCheck className="w-3 h-3 inline mr-1" />
                AXITCHE surveille les messages. Seuls les echanges commerciaux sont autorises.
              </p>
            </div>

            {/* Input message */}
            <div className="flex items-center gap-2 pt-4 border-t border-gray-800">
              <input
                type="text"
                value={nouveauMessage}
                onChange={(e) => setNouveauMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && envoyerMessage()}
                placeholder="Votre message..."
                className="flex-1 bg-[#1A1A1A] border border-gray-800 rounded-full px-4 py-3 text-white placeholder-gray-500 focus:border-[#00FF88] focus:outline-none"
              />
              <button onClick={envoyerMessage} className="bg-[#00FF88] p-3 rounded-full hover:bg-[#00DD77] transition">
                <Send className="w-5 h-5 text-black" />
              </button>
            </div>
          </div>
        )}

        {/* VUE PROFIL VENDEUR (style Facebook) */}
        {vue === "profil" && produitSelectionne && (
          <div className="space-y-4">
            <button onClick={() => setVue("accueil")} className="flex items-center gap-2 text-gray-400 hover:text-white">
              <ChevronLeft className="w-5 h-5" />
              Retour
            </button>

            {/* Bannière et photo */}
            <div className="relative">
              <div className="h-32 bg-gradient-to-r from-[#00FF88]/20 to-[#00AA55]/20 rounded-2xl"></div>
              <div className="absolute -bottom-12 left-4">
                <img
                  src={produitSelectionne.vendeur.photo}
                  alt={produitSelectionne.vendeur.nom}
                  className="w-24 h-24 rounded-full border-4 border-[#0A0A0A] object-cover"
                />
              </div>
            </div>

            {/* Infos vendeur */}
            <div className="pt-14 px-1">
              <h2 className="text-xl font-bold">{produitSelectionne.vendeur.nom}</h2>
              <div className="flex items-center gap-2 mt-1 text-gray-400 text-sm">
                <MapPin className="w-4 h-4" />
                <span>{produitSelectionne.ville}</span>
              </div>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="font-semibold">{produitSelectionne.vendeur.note}</span>
                  <span className="text-gray-400 text-sm">({produitSelectionne.vendeur.avis} avis)</span>
                </div>
              </div>
            </div>

            {/* Statistiques */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-[#1A1A1A] rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-[#00FF88]">{produitSelectionne.vendeur.produits}</p>
                <p className="text-xs text-gray-400">Produits</p>
              </div>
              <div className="bg-[#1A1A1A] rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-[#00FF88]">{produitSelectionne.vendeur.note}</p>
                <p className="text-xs text-gray-400">Note</p>
              </div>
              <div className="bg-[#1A1A1A] rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-[#00FF88]">{produitSelectionne.vendeur.membres_depuis}</p>
                <p className="text-xs text-gray-400">Membre</p>
              </div>
            </div>

            {/* Options style Facebook */}
            <div className="bg-[#1A1A1A] rounded-2xl overflow-hidden">
              <button
                onClick={() => ouvrirItineraire(produitSelectionne.vendeur.lat, produitSelectionne.vendeur.lng)}
                className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800"
              >
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <Navigation className="w-5 h-5 text-blue-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Itinéraire Google Maps</p>
                  <p className="text-xs text-gray-400">Voir la localisation du vendeur</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button
                onClick={() => contacterWhatsApp(produitSelectionne.vendeur.whatsapp, produitSelectionne.titre)}
                className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800"
              >
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Phone className="w-5 h-5 text-green-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Contacter sur WhatsApp</p>
                  <p className="text-xs text-gray-400">{produitSelectionne.vendeur.whatsapp}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button
                onClick={() => ouvrirNegociation(produitSelectionne)}
                className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800"
              >
                <div className="w-10 h-10 rounded-full bg-[#00FF88]/20 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-[#00FF88]" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Négocier le prix</p>
                  <p className="text-xs text-gray-400">Discuter directement avec le vendeur</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Package className="w-5 h-5 text-purple-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Voir tous les produits</p>
                  <p className="text-xs text-gray-400">{produitSelectionne.vendeur.produits} articles en vente</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition">
                <div className="w-10 h-10 rounded-full bg-yellow-500/20 flex items-center justify-center">
                  <Star className="w-5 h-5 text-yellow-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Voir les avis</p>
                  <p className="text-xs text-gray-400">{produitSelectionne.vendeur.avis} avis clients</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>
            </div>
          </div>
        )}

        {/* VUE MON PROFIL (style Facebook) */}
        {vue === "mon-profil" && utilisateur && (
          <div className="space-y-4">
            {/* Bannière et photo */}
            <div className="relative">
              <div className="h-32 bg-gradient-to-r from-[#00FF88]/30 to-[#00AA55]/30 rounded-2xl"></div>
              <div className="absolute -bottom-12 left-4">
                <div className="relative">
                  <img
                    src={utilisateur.photo}
                    alt={utilisateur.nom}
                    className="w-24 h-24 rounded-full border-4 border-[#0A0A0A] object-cover"
                  />
                  <button className="absolute bottom-0 right-0 bg-[#00FF88] p-1.5 rounded-full">
                    <Camera className="w-4 h-4 text-black" />
                  </button>
                </div>
              </div>
            </div>

            {/* Infos profil */}
            <div className="pt-14 px-1">
              <h2 className="text-xl font-bold">{utilisateur.prenom} {utilisateur.nom}</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                  utilisateur.typeCompte === "vendeur" ? "bg-[#00FF88]/20 text-[#00FF88]" : "bg-blue-500/20 text-blue-400"
                }`}>
                  {utilisateur.typeCompte === "vendeur" ? "Vendeur" : "Acheteur"}
                </span>
                {utilisateur.nomProduit && (
                  <span className="text-gray-400 text-sm">• {utilisateur.nomProduit}</span>
                )}
              </div>
              <div className="flex items-center gap-2 mt-2 text-gray-400 text-sm">
                <MapPin className="w-4 h-4" />
                <span>{utilisateur.ville}</span>
              </div>
            </div>

            {/* Statistiques */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-[#1A1A1A] rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-[#00FF88]">{utilisateur.produits}</p>
                <p className="text-xs text-gray-400">Produits</p>
              </div>
              <div className="bg-[#1A1A1A] rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-[#00FF88]">{utilisateur.note}</p>
                <p className="text-xs text-gray-400">Note</p>
              </div>
              <div className="bg-[#1A1A1A] rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-[#00FF88]">{utilisateur.avis}</p>
                <p className="text-xs text-gray-400">Avis</p>
              </div>
            </div>

            {/* Options du profil style Facebook */}
            <div className="bg-[#1A1A1A] rounded-2xl overflow-hidden">
              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <Edit3 className="w-5 h-5 text-blue-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Modifier mon profil</p>
                  <p className="text-xs text-gray-400">Photo, nom, informations</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              {utilisateur.typeCompte === "vendeur" && (
                <button 
                  onClick={() => setVue("vendre")}
                  className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800"
                >
                  <div className="w-10 h-10 rounded-full bg-[#00FF88]/20 flex items-center justify-center">
                    <Plus className="w-5 h-5 text-[#00FF88]" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium">Ajouter un produit</p>
                    <p className="text-xs text-gray-400">Publier une nouvelle annonce</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-500" />
                </button>
              )}

              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Package className="w-5 h-5 text-purple-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Mes produits</p>
                  <p className="text-xs text-gray-400">{utilisateur.produits} articles en vente</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <Heart className="w-5 h-5 text-red-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Mes favoris</p>
                  <p className="text-xs text-gray-400">Produits sauvegardés</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-orange-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Historique</p>
                  <p className="text-xs text-gray-400">Vos achats et ventes</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-yellow-500/20 flex items-center justify-center">
                  <Star className="w-5 h-5 text-yellow-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Mes avis</p>
                  <p className="text-xs text-gray-400">{utilisateur.avis} avis reçus</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Paramètres */}
            <div className="bg-[#1A1A1A] rounded-2xl overflow-hidden">
              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-gray-500/20 flex items-center justify-center">
                  <Settings className="w-5 h-5 text-gray-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Paramètres</p>
                  <p className="text-xs text-gray-400">Notifications, confidentialité</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition border-b border-gray-800">
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                  <HelpCircle className="w-5 h-5 text-cyan-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium">Aide et support</p>
                  <p className="text-xs text-gray-400">FAQ, contacter le support</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-500" />
              </button>

              <button 
                onClick={handleDeconnexion}
                className="w-full flex items-center gap-4 p-4 hover:bg-[#252525] transition"
              >
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <LogOut className="w-5 h-5 text-red-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium text-red-400">Déconnexion</p>
                  <p className="text-xs text-gray-400">Se déconnecter du compte</p>
                </div>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Modal partage avec QR Code */}
      {afficherPartage && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4">
          <div className="bg-[#1A1A1A] rounded-3xl w-full max-w-sm overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-[#00FF88]/20 to-[#00AA55]/20 p-6 text-center relative">
              <button
                onClick={() => setAfficherPartage(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
              <div className="w-16 h-16 bg-[#00FF88] rounded-2xl flex items-center justify-center mx-auto mb-3">
                <Store className="w-8 h-8 text-black" />
              </div>
              <h2 className="text-xl font-bold">AXITCHE</h2>
              <p className="text-gray-400 text-sm mt-1">Marche Local du Benin</p>
            </div>

            {/* QR Code */}
            <div className="p-6 flex flex-col items-center">
              <div className="bg-white p-4 rounded-2xl shadow-lg">
                <QRCodeSVG
                  value={appUrl || "https://axitche.vercel.app"}
                  size={180}
                  bgColor="#FFFFFF"
                  fgColor="#0A0A0A"
                  level="H"
                  includeMargin={false}
                />
              </div>
              <p className="text-gray-400 text-sm mt-4 text-center">
                Scannez ce code QR pour acceder a AXITCHE
              </p>
            </div>

            {/* Lien de l'application */}
            <div className="px-6 pb-4">
              <div className="bg-[#252525] rounded-xl p-3 flex items-center gap-3">
                <Link2 className="w-5 h-5 text-[#00FF88] flex-shrink-0" />
                <p className="text-sm text-gray-300 truncate flex-1">{appUrl || "https://axitche.vercel.app"}</p>
                <button
                  onClick={copierLien}
                  className="bg-[#00FF88]/20 p-2 rounded-lg hover:bg-[#00FF88]/30 transition"
                >
                  {lienCopie ? (
                    <CheckCircle className="w-4 h-4 text-[#00FF88]" />
                  ) : (
                    <Copy className="w-4 h-4 text-[#00FF88]" />
                  )}
                </button>
              </div>
              {lienCopie && (
                <p className="text-[#00FF88] text-xs text-center mt-2">Lien copie!</p>
              )}
            </div>

            {/* Boutons de partage */}
            <div className="px-6 pb-6 space-y-3">
              <button
                onClick={() => {
                  window.open(`https://wa.me/?text=Decouvre AXITCHE, l'application pour acheter et vendre des produits locaux au Benin! ${appUrl}`, "_blank")
                }}
                className="w-full bg-green-600 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-green-700 transition"
              >
                <Phone className="w-5 h-5" />
                Partager sur WhatsApp
              </button>
              <button
                onClick={() => {
                  window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(appUrl)}`, "_blank")
                }}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-blue-700 transition"
              >
                <Share2 className="w-5 h-5" />
                Partager sur Facebook
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Navigation bottom (visible seulement si connecte) */}
      {estConnecte && (
        <nav className="fixed bottom-0 left-0 right-0 bg-[#0A0A0A]/95 backdrop-blur border-t border-[#00FF88]/20 px-4 py-2 z-50">
          <div className="flex items-center justify-around">
            <button
              onClick={() => setVue("accueil")}
              className={`flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition ${vue === "accueil" ? "text-[#00FF88]" : "text-gray-500"}`}
            >
              <Home className="w-6 h-6" />
              <span className="text-[10px]">Marche</span>
            </button>

            <button
              onClick={() => setAfficherPartage(true)}
              className="flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition text-gray-500 hover:text-[#00FF88]"
            >
              <Share2 className="w-6 h-6" />
              <span className="text-[10px]">Partager</span>
            </button>

            {utilisateur?.typeCompte === "vendeur" && (
              <button
                onClick={() => setVue("vendre")}
                className={`flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition ${vue === "vendre" ? "text-[#00FF88]" : "text-gray-500"}`}
              >
                <Camera className="w-6 h-6" />
                <span className="text-[10px]">Vendre</span>
              </button>
            )}

            <button
              onClick={() => setVue("mon-profil")}
              className={`flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition ${vue === "mon-profil" ? "text-[#00FF88]" : "text-gray-500"}`}
            >
              <User className="w-6 h-6" />
              <span className="text-[10px]">Profil</span>
            </button>
          </div>
        </nav>
      )}
    </div>
  )
}
